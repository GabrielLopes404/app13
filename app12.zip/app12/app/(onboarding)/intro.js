/**
 * ✨ PREMIUM ONBOARDING EXPERIENCE - PETSGO ✨
 * 
 * Tela de introdução com design de nível mundial
 * Inspirado nos melhores apps: Uber, Airbnb, Apple
 * 
 * 3 Slides Premium:
 * 1. HERO - Apresentação impactante com mascote gigante
 * 2. FEATURES - Showcase de recursos com cards glassmorphism
 * 3. CTA - Chamada para ação irresistível com oferta especial
 */

import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Dimensions, FlatList, TouchableOpacity, StatusBar, Platform } from 'react-native';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  useAnimatedScrollHandler,
  withTiming,
  withDelay,
  withSpring,
  withSequence,
  withRepeat,
  interpolate,
  interpolateColor,
  Extrapolate,
  Easing,
  runOnJS,
} from 'react-native-reanimated';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import Button from '../../components/Button';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius } from '../../constants/theme';

const { width, height } = Dimensions.get('window');
const SLIDE_WIDTH = width;

// 🎨 NOVA PALETA DE CORES PREMIUM
const PREMIUM_COLORS = {
  slide1: {
    primary: '#6366F1', // Indigo vibrante
    secondary: '#8B5CF6', // Roxo profundo
    accent: '#EC4899', // Rosa vibrante
    gradient: ['#667EEA', '#764BA2', '#F093FB'],
  },
  slide2: {
    primary: '#10B981', // Verde esmeralda
    secondary: '#059669',
    accent: '#34D399',
    gradient: ['#0EA5E9', '#10B981', '#34D399'],
  },
  slide3: {
    primary: '#F59E0B', // Âmbar
    secondary: '#EF4444', // Vermelho
    accent: '#FBBF24',
    gradient: ['#F59E0B', '#EF4444', '#EC4899'],
  },
};

// 📱 CONTEÚDO DOS SLIDES REFORMULADOS
const slides = [
  {
    id: '1',
    // SLIDE 1: HERO IMPACTANTE
    emoji: '🐕',
    emojiSize: 120,
    title: 'Tudo para seu\nmelhor amigo',
    titleHighlight: 'melhor amigo',
    subtitle: 'Produtos premium, serviços profissionais\ne muito carinho em um só app',
    gradient: PREMIUM_COLORS.slide1.gradient,
    bgColor: PREMIUM_COLORS.slide1.primary,
    particles: [
      { emoji: '🐾', x: 0.2, y: 0.15, scale: 1.2, duration: 3000 },
      { emoji: '💝', x: 0.8, y: 0.2, scale: 0.9, duration: 4000 },
      { emoji: '⭐', x: 0.1, y: 0.7, scale: 1.0, duration: 3500 },
      { emoji: '✨', x: 0.85, y: 0.75, scale: 0.8, duration: 4500 },
      { emoji: '🐈', x: 0.5, y: 0.85, scale: 1.1, duration: 3800 },
    ],
    features: null,
    cta: false,
  },
  {
    id: '2',
    // SLIDE 2: FEATURES COM GLASSMORPHISM
    emoji: '✨',
    emojiSize: 80,
    title: 'Tudo que você\nprecisa, aqui',
    titleHighlight: 'aqui',
    subtitle: 'Uma experiência completa de cuidados',
    gradient: PREMIUM_COLORS.slide2.gradient,
    bgColor: PREMIUM_COLORS.slide2.primary,
    particles: [
      { emoji: '💎', x: 0.15, y: 0.18, scale: 0.9, duration: 3200 },
      { emoji: '🌟', x: 0.82, y: 0.25, scale: 1.0, duration: 3700 },
      { emoji: '⚡', x: 0.9, y: 0.8, scale: 0.85, duration: 4200 },
    ],
    features: [
      { 
        icon: 'flash-outline', 
        iconColor: '#F59E0B',
        title: 'Entrega Ultra Rápida', 
        desc: 'Receba em até 2 horas\nna sua casa',
        gradient: ['rgba(245, 158, 11, 0.15)', 'rgba(245, 158, 11, 0.05)'],
      },
      { 
        icon: 'shield-checkmark-outline', 
        iconColor: '#10B981',
        title: 'Produtos Certificados', 
        desc: '100% originais e\nseguros',
        gradient: ['rgba(16, 185, 129, 0.15)', 'rgba(16, 185, 129, 0.05)'],
      },
      { 
        icon: 'calendar-outline', 
        iconColor: '#6366F1',
        title: 'Agende com 1 Toque', 
        desc: 'Serviços quando\nvocê quiser',
        gradient: ['rgba(99, 102, 241, 0.15)', 'rgba(99, 102, 241, 0.05)'],
      },
      { 
        icon: 'pricetag-outline', 
        iconColor: '#EC4899',
        title: 'Ofertas Exclusivas', 
        desc: 'Descontos toda\nsemana',
        gradient: ['rgba(236, 72, 153, 0.15)', 'rgba(236, 72, 153, 0.05)'],
      },
    ],
    cta: false,
  },
  {
    id: '3',
    // SLIDE 3: CTA IRRESISTÍVEL
    emoji: '🎉',
    emojiSize: 100,
    title: 'Comece agora\ncom desconto!',
    titleHighlight: 'com desconto',
    subtitle: 'Milhares de tutores já confiam no PetsGo\npara cuidar de seus pets com amor',
    gradient: PREMIUM_COLORS.slide3.gradient,
    bgColor: PREMIUM_COLORS.slide3.primary,
    particles: [
      { emoji: '🎊', x: 0.18, y: 0.2, scale: 1.1, duration: 3100 },
      { emoji: '💖', x: 0.78, y: 0.18, scale: 1.0, duration: 3600 },
      { emoji: '🌟', x: 0.12, y: 0.75, scale: 0.9, duration: 4100 },
      { emoji: '✨', x: 0.88, y: 0.78, scale: 0.85, duration: 3900 },
    ],
    features: null,
    cta: true,
    offer: {
      badge: '🎁 OFERTA ESPECIAL',
      discount: '15% OFF',
      text: 'na primeira compra',
    },
  },
];

/**
 * 🎭 Componente de Partícula Flutuante
 * Animação suave e orgânica com movimento circular
 */
function FloatingParticle({ particle, index, scrollX, slideIndex }) {
  const offsetX = particle.x * width;
  const offsetY = particle.y * height;
  
  const floatY = useSharedValue(0);
  const floatX = useSharedValue(0);
  const rotate = useSharedValue(0);

  useEffect(() => {
    // Movimento de flutuação vertical suave
    floatY.value = withRepeat(
      withSequence(
        withTiming(-20, { duration: particle.duration, easing: Easing.inOut(Easing.sine) }),
        withTiming(0, { duration: particle.duration, easing: Easing.inOut(Easing.sine) })
      ),
      -1,
      false
    );

    // Movimento horizontal sutil
    floatX.value = withRepeat(
      withSequence(
        withTiming(15, { duration: particle.duration * 1.3, easing: Easing.inOut(Easing.sine) }),
        withTiming(0, { duration: particle.duration * 1.3, easing: Easing.inOut(Easing.sine) })
      ),
      -1,
      false
    );

    // Rotação lenta
    rotate.value = withRepeat(
      withTiming(360, { duration: particle.duration * 3, easing: Easing.linear }),
      -1,
      false
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => {
    const inputRange = [
      (slideIndex - 1) * width,
      slideIndex * width,
      (slideIndex + 1) * width,
    ];
    
    const opacity = interpolate(
      scrollX.value,
      inputRange,
      [0, 1, 0],
      Extrapolate.CLAMP
    );

    const scale = interpolate(
      scrollX.value,
      inputRange,
      [0.3, particle.scale, 0.3],
      Extrapolate.CLAMP
    );

    return {
      opacity: opacity * 0.7,
      transform: [
        { translateX: offsetX + floatX.value },
        { translateY: offsetY + floatY.value },
        { scale },
        { rotate: `${rotate.value}deg` },
      ],
    };
  });

  return (
    <Animated.Text style={[styles.particle, animatedStyle]}>
      {particle.emoji}
    </Animated.Text>
  );
}

/**
 * 💳 Card de Feature com Glassmorphism
 * Design moderno com efeito de vidro fosco
 */
function GlassFeatureCard({ feature, index, scrollX, slideIndex }) {
  const animatedStyle = useAnimatedStyle(() => {
    const inputRange = [
      (slideIndex - 1) * width,
      slideIndex * width,
      (slideIndex + 1) * width,
    ];

    const opacity = interpolate(
      scrollX.value,
      inputRange,
      [0, 1, 0],
      Extrapolate.CLAMP
    );

    const translateY = interpolate(
      scrollX.value,
      inputRange,
      [60, 0, -60],
      Extrapolate.CLAMP
    );

    const scale = interpolate(
      scrollX.value,
      inputRange,
      [0.7, 1, 0.7],
      Extrapolate.CLAMP
    );

    return {
      opacity,
      transform: [
        { translateY },
        { scale },
      ],
    };
  });

  return (
    <Animated.View 
      style={[
        styles.glassCard,
        animatedStyle,
        { 
          backgroundColor: 'rgba(255, 255, 255, 0.15)',
          borderColor: 'rgba(255, 255, 255, 0.3)',
        }
      ]}
      entering={undefined}
    >
      <LinearGradient
        colors={feature.gradient}
        style={styles.featureIconBg}
      >
        <Ionicons name={feature.icon} size={32} color={feature.iconColor} />
      </LinearGradient>
      <Text style={styles.featureTitle}>{feature.title}</Text>
      <Text style={styles.featureDesc}>{feature.desc}</Text>
    </Animated.View>
  );
}

/**
 * 🎬 Slide Individual
 */
function SlideContent({ item, index, scrollX }) {
  const slideAnimStyle = useAnimatedStyle(() => {
    const inputRange = [
      (index - 1) * width,
      index * width,
      (index + 1) * width,
    ];

    const opacity = interpolate(
      scrollX.value,
      inputRange,
      [0.4, 1, 0.4],
      Extrapolate.CLAMP
    );

    const scale = interpolate(
      scrollX.value,
      inputRange,
      [0.85, 1, 0.85],
      Extrapolate.CLAMP
    );

    return {
      opacity,
      transform: [{ scale }],
    };
  });

  const emojiAnimStyle = useAnimatedStyle(() => {
    const inputRange = [
      (index - 1) * width,
      index * width,
      (index + 1) * width,
    ];

    const scale = interpolate(
      scrollX.value,
      inputRange,
      [0.5, 1, 0.5],
      Extrapolate.CLAMP
    );

    const rotateZ = interpolate(
      scrollX.value,
      inputRange,
      [-20, 0, 20],
      Extrapolate.CLAMP
    );

    return {
      transform: [
        { scale },
        { rotateZ: `${rotateZ}deg` },
      ],
    };
  });

  return (
    <View style={styles.slide}>
      {/* Background Gradient Animado */}
      <LinearGradient
        colors={item.gradient}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill}
      />

      {/* Partículas Flutuantes */}
      {item.particles.map((particle, i) => (
        <FloatingParticle 
          key={i} 
          particle={particle} 
          index={i} 
          scrollX={scrollX} 
          slideIndex={index} 
        />
      ))}

      {/* Conteúdo Principal */}
      <Animated.View style={[styles.content, slideAnimStyle]}>
        {/* Emoji Hero */}
        <Animated.Text style={[styles.emojiHero, { fontSize: item.emojiSize }, emojiAnimStyle]}>
          {item.emoji}
        </Animated.Text>

        {/* Título */}
        <View style={styles.textContainer}>
          <Text style={styles.title}>
            {item.title.split('\n').map((line, i) => (
              <Text key={i}>
                {line.includes(item.titleHighlight) ? (
                  <>
                    {line.split(item.titleHighlight)[0]}
                    <Text style={styles.titleHighlight}>{item.titleHighlight}</Text>
                    {line.split(item.titleHighlight)[1]}
                  </>
                ) : (
                  line
                )}
                {i === 0 && '\n'}
              </Text>
            ))}
          </Text>
          
          <Text style={styles.subtitle}>{item.subtitle}</Text>
        </View>

        {/* Features Grid (Slide 2) */}
        {item.features && (
          <View style={styles.featuresGrid}>
            {item.features.map((feature, i) => (
              <GlassFeatureCard
                key={i}
                feature={feature}
                index={i}
                scrollX={scrollX}
                slideIndex={index}
              />
            ))}
          </View>
        )}

        {/* CTA Badge e Oferta (Slide 3) */}
        {item.cta && item.offer && (
          <View style={styles.offerContainer}>
            {/* Badge de Oferta Especial */}
            <View style={styles.offerBadge}>
              <LinearGradient
                colors={['rgba(255, 255, 255, 0.3)', 'rgba(255, 255, 255, 0.1)']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.offerBadgeGradient}
              >
                <Text style={styles.offerBadgeText}>{item.offer.badge}</Text>
              </LinearGradient>
            </View>

            {/* Destaque do Desconto */}
            <View style={styles.discountBox}>
              <Text style={styles.discountText}>{item.offer.discount}</Text>
              <Text style={styles.discountSubtext}>{item.offer.text}</Text>
            </View>
          </View>
        )}
      </Animated.View>
    </View>
  );
}

/**
 * 🎯 Indicador de Página Premium
 */
function PaginationDot({ index, scrollX }) {
  const animatedStyle = useAnimatedStyle(() => {
    const inputRange = [
      (index - 1) * width,
      index * width,
      (index + 1) * width,
    ];

    const dotWidth = interpolate(
      scrollX.value,
      inputRange,
      [8, 32, 8],
      Extrapolate.CLAMP
    );

    const opacity = interpolate(
      scrollX.value,
      inputRange,
      [0.3, 1, 0.3],
      Extrapolate.CLAMP
    );

    return {
      width: dotWidth,
      opacity,
    };
  });

  return (
    <Animated.View style={[styles.paginationDot, animatedStyle]} />
  );
}

/**
 * 🏠 COMPONENTE PRINCIPAL
 */
export default function IntroScreen() {
  const router = useRouter();
  const scrollX = useSharedValue(0);
  const flatListRef = useRef(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollX.value = event.contentOffset.x;
      const index = Math.round(event.contentOffset.x / width);
      runOnJS(setCurrentIndex)(index);
    },
  });

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({
        index: currentIndex + 1,
        animated: true,
      });
    } else {
      router.push('/(onboarding)/signup');
    }
  };

  const handleSkip = () => {
    router.push('/(onboarding)/login');
  };

  const isLastSlide = currentIndex === slides.length - 1;

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Skip Button */}
      {!isLastSlide && (
        <SafeAreaView style={styles.skipContainer} edges={['top']}>
          <TouchableOpacity 
            onPress={handleSkip}
            style={styles.skipButton}
            activeOpacity={0.7}
          >
            <Text style={styles.skipText}>Pular</Text>
            <Ionicons name="arrow-forward" size={16} color="rgba(255,255,255,0.9)" />
          </TouchableOpacity>
        </SafeAreaView>
      )}

      {/* Slides */}
      <Animated.FlatList
        ref={flatListRef}
        data={slides}
        renderItem={({ item, index }) => (
          <SlideContent item={item} index={index} scrollX={scrollX} />
        )}
        keyExtractor={(item) => item.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={scrollHandler}
        scrollEventThrottle={16}
        bounces={false}
        decelerationRate="fast"
      />

      {/* Bottom Section */}
      <SafeAreaView style={styles.bottomContainer} edges={['bottom']}>
        {/* Pagination Dots */}
        <View style={styles.pagination}>
          {slides.map((_, index) => (
            <PaginationDot key={index} index={index} scrollX={scrollX} />
          ))}
        </View>

        {/* Action Buttons */}
        <View style={styles.buttonsContainer}>
          {isLastSlide ? (
            <>
              <Button
                title="Criar Conta Grátis"
                onPress={() => router.push('/(onboarding)/signup')}
                style={styles.primaryButton}
              />
              <TouchableOpacity
                onPress={() => router.push('/(onboarding)/login')}
                style={styles.secondaryButton}
                activeOpacity={0.7}
              >
                <Text style={styles.secondaryButtonText}>Já tenho conta</Text>
              </TouchableOpacity>
            </>
          ) : (
            <Button
              title="Continuar"
              onPress={handleNext}
              style={styles.primaryButton}
              icon={<Ionicons name="arrow-forward" size={20} color={Colors.backgroundLight} />}
              iconPosition="right"
            />
          )}
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  slide: {
    width: SLIDE_WIDTH,
    height: height,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.xxxl * 2,
  },
  
  // Emoji Hero
  emojiHero: {
    marginBottom: Spacing.xxl,
    textAlign: 'center',
  },
  
  // Textos
  textContainer: {
    alignItems: 'center',
    marginBottom: Spacing.xxxl,
  },
  title: {
    fontSize: width > 375 ? 42 : 36,
    fontWeight: '800',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: Spacing.lg,
    lineHeight: width > 375 ? 50 : 44,
    letterSpacing: -0.5,
  },
  titleHighlight: {
    color: '#FBBF24',
    textShadowColor: 'rgba(251, 191, 36, 0.5)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
  },
  subtitle: {
    fontSize: width > 375 ? 17 : 15,
    color: 'rgba(255, 255, 255, 0.85)',
    textAlign: 'center',
    lineHeight: 26,
    fontWeight: '400',
    paddingHorizontal: Spacing.md,
  },

  // Features Grid (Slide 2)
  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: Spacing.md,
    maxWidth: 400,
    marginTop: Spacing.lg,
  },
  glassCard: {
    width: (width - Spacing.xl * 2 - Spacing.md) / 2,
    minHeight: 160,
    padding: Spacing.lg,
    borderRadius: BorderRadius.xl,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.3,
        shadowRadius: 16,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  featureIconBg: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.md,
  },
  featureTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: Spacing.xs,
    lineHeight: 20,
  },
  featureDesc: {
    fontSize: 13,
    color: 'rgba(255, 255, 255, 0.75)',
    textAlign: 'center',
    lineHeight: 18,
  },

  // Oferta (Slide 3)
  offerContainer: {
    alignItems: 'center',
    marginTop: Spacing.xl,
  },
  offerBadge: {
    marginBottom: Spacing.lg,
  },
  offerBadgeGradient: {
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  offerBadgeText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#FFFFFF',
    letterSpacing: 1,
  },
  discountBox: {
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    paddingVertical: Spacing.xl,
    paddingHorizontal: Spacing.xxl,
    borderRadius: BorderRadius.xl,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  discountText: {
    fontSize: 48,
    fontWeight: '900',
    color: '#FFFFFF',
    marginBottom: Spacing.xs,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
  },
  discountSubtext: {
    fontSize: 16,
    fontWeight: '600',
    color: 'rgba(255, 255, 255, 0.9)',
  },

  // Partículas
  particle: {
    position: 'absolute',
    fontSize: 32,
  },

  // Skip Button
  skipContainer: {
    position: 'absolute',
    top: 0,
    right: 0,
    zIndex: 10,
    paddingRight: Spacing.lg,
    paddingTop: Spacing.md,
  },
  skipButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.full,
  },
  skipText: {
    color: 'rgba(255, 255, 255, 0.9)',
    fontSize: 14,
    fontWeight: '600',
  },

  // Bottom Section
  bottomContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.lg,
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
    marginBottom: Spacing.xxl,
  },
  paginationDot: {
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
  },
  buttonsContainer: {
    gap: Spacing.md,
  },
  primaryButton: {
    backgroundColor: '#FFFFFF',
    paddingVertical: Spacing.lg,
  },
  secondaryButton: {
    alignItems: 'center',
    paddingVertical: Spacing.md,
  },
  secondaryButtonText: {
    color: 'rgba(255, 255, 255, 0.9)',
    fontSize: 16,
    fontWeight: '600',
  },
});
