import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withSequence,
} from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows, Motion } from '../constants/theme';
import { useResponsiveLayout } from '../hooks/useResponsiveLayout';

const QUICK_ACTIONS = [
  { id: 'scan', icon: 'qr-code', label: 'Escanear', gradient: Colors.gradientPrimary },
  { id: 'cart', icon: 'cart', label: 'Carrinho', gradient: Colors.gradientTwilight, badge: 3 },
  { id: 'orders', icon: 'receipt', label: 'Pedidos', gradient: Colors.gradientBlue },
  { id: 'help', icon: 'help-circle', label: 'Ajuda', gradient: Colors.gradientPremiumEmerald },
];

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export default function FloatingActionDock({ onActionPress, containerStyle }) {
  const { isXS, spacing } = useResponsiveLayout();

  return (
    <View style={[styles.container, containerStyle]}>
      <View style={[styles.dock, { gap: isXS ? spacing.sm : spacing.md }]}>
        {QUICK_ACTIONS.map((action, index) => (
          <ActionButton
            key={action.id}
            action={action}
            onPress={() => onActionPress?.(action)}
            delay={index * 50}
          />
        ))}
      </View>
    </View>
  );
}

function ActionButton({ action, onPress, delay }) {
  const scale = useSharedValue(1);
  const shadowScale = useSharedValue(1);

  const buttonAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const shadowAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: shadowScale.value }],
    opacity: shadowScale.value - 1,
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.9, Motion.spring.snappy);
    shadowScale.value = withSpring(1.2, Motion.spring.bouncy);
  };

  const handlePressOut = () => {
    scale.value = withSequence(
      withSpring(1.05, Motion.spring.bouncy),
      withSpring(1, Motion.spring.gentle)
    );
    shadowScale.value = withSpring(1, Motion.spring.gentle);
  };

  return (
    <View style={styles.actionButtonContainer}>
      <Animated.View style={[styles.shadowCircle, shadowAnimatedStyle]}>
        <LinearGradient
          colors={action.gradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.shadowGradient}
        />
      </Animated.View>

      <AnimatedTouchable
        style={[styles.actionButton, buttonAnimatedStyle]}
        activeOpacity={0.9}
        onPress={onPress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
      >
        <LinearGradient
          colors={action.gradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.gradient}
        >
          <Ionicons name={action.icon} size={24} color={Colors.textLight} />
          
          {action.badge && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{action.badge}</Text>
            </View>
          )}
        </LinearGradient>
      </AnimatedTouchable>

      <Text style={styles.actionLabel} numberOfLines={1}>
        {action.label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: Spacing.lg,
  },
  dock: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
  },
  actionButtonContainer: {
    alignItems: 'center',
    position: 'relative',
  },
  shadowCircle: {
    position: 'absolute',
    top: 0,
    left: '50%',
    marginLeft: -28,
    width: 56,
    height: 56,
    borderRadius: 28,
    opacity: 0.3,
  },
  shadowGradient: {
    flex: 1,
    borderRadius: 28,
  },
  actionButton: {
    width: 56,
    height: 56,
    borderRadius: 28,
    overflow: 'hidden',
    ...Shadows.large,
  },
  gradient: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badge: {
    position: 'absolute',
    top: 4,
    right: 4,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: Colors.error,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
    borderWidth: 2,
    borderColor: Colors.textLight,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  actionLabel: {
    marginTop: Spacing.xs,
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.medium,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
});
