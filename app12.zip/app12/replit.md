# PetsGo - Mobile App for Pet Services

## Overview

PetsGo is a premium mobile application for iOS and Android that connects pet owners with local pet services and products. Built with React Native and Expo, it features a modern, fluid UI inspired by leading food delivery apps but tailored specifically for the pet services industry. The app provides a comprehensive marketplace for pet grooming, veterinary clinics, pet shops, pharmacies, walking services, training, and emergency care.

The application emphasizes a premium user experience through cinematic animations, sophisticated design patterns, and smooth microinteractions powered by React Native Reanimated.

## Recent Changes (November 2025)

**Premium Onboarding Redesign & Code Cleanup (November 10, 2025)**
- ✨ **NOVO**: Telas de introdução completamente renovadas com design premium e comercial
  - Slide 1: Boas-vindas com mascote estilizado e visual moderno
  - Slide 2: Cards de benefícios animados em grid responsivo
  - Slide 3: CTA poderoso com badge de oferta (10% OFF)
  - Animações cinematográficas e partículas flutuantes
  - Gradientes animados e transições suaves
  - Design responsivo otimizado para todos os tamanhos de tela
- 🧹 **LIMPEZA**: Removidos arquivos backup desnecessários (index.js.backup, .problem, .full)
- 📝 **DOCUMENTAÇÃO**: Adicionados comentários explicativos em componentes complexos
- 🎨 **PADRONIZAÇÃO**: Melhorias na estrutura e consistência visual
- ✅ Código limpo, organizado e bem documentado

**Replit Environment Setup & New Pages (November 10, 2025)**
- Configured project to run on Replit with port 5000 and proper host settings
- Created complete set of profile navigation pages:
  - Personal Data (`/personal-data`) - User profile editing with pet management
  - Addresses (`/addresses`) - Saved addresses management
  - Payment Methods (`/payment-methods`) - Credit card management
  - Notifications (`/notifications`) - Real-time notifications center
  - Notification Settings (`/notification-settings`) - Notification preferences
  - Help Center (`/help-center`) - Customer support hub
  - FAQ (`/faq`) - Frequently asked questions with expandable answers
  - Privacy & Security (`/privacy-security`) - Account security and privacy settings
  - Terms of Use (`/terms`) - Legal terms and conditions
- Updated Profile page to navigate to all new pages
- Added proper .gitignore for Node.js and Expo projects
- Configured workflow for web deployment

**Mobile Optimization Updates**
- Optimized Orders page with improved card layout and compact spacing for mobile screens
- Enhanced Favorites page with responsive grid layout and adaptive filters
- Improved Order Detail page with reduced padding and optimized component sizes for small screens
- Updated StoreCardCompact component with dynamic sizing based on screen width
- All pages now fully optimized for mobile screens, including devices < 360px width
- Removed unused dependencies and cleaned up imports

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Navigation**
- **React Native (0.81.5) with Expo (~54.0.23)**: Cross-platform mobile development framework enabling iOS and Android deployment from a single codebase
- **Expo Router (^6.0.14)**: File-based routing system providing declarative navigation with Stack and Tabs patterns
- **React Navigation**: Bottom tabs for main sections (Home, Orders, Favorites, Profile) with stack navigation for detailed flows

**Animation System**
- **React Native Reanimated (^4.1.3)**: High-performance animations running on native thread for smooth 60fps experiences
- **React Native Gesture Handler (^2.29.1)**: Native touch gesture recognition for swipe, press, and pull-to-refresh interactions
- **React Native Worklets (^0.6.1)**: JavaScript code execution on UI thread for zero-lag animations
- Shared animation components (PressableScale, AnimatedGradient) for consistent microinteractions across the app

**UI Component System**
- Atomic design methodology with reusable components (Button, Input, Card, Badge, SkeletonLoader)
- Custom components for domain-specific needs (StoreCard, ProductCard, CategoryCard)
- Centralized theme system with design tokens (Colors, Spacing, FontSizes, BorderRadius, Shadows)
- Consistent visual language: no gradients, flat modern design with subtle shadows for depth

**Design Tokens & Theme**
- Primary color: #4F5DFF (vibrant purple-blue)
- Accent color: #00C2A8 (teal for CTAs)
- Neutral grays: #F5F6FA, #EEEEF5, #A7A7B7 for backgrounds and secondary elements
- Semantic colors for status (success/error/warning/info)
- Typography hierarchy with comfortable spacing
- Shadow system (xs, small, medium, large) for elevation and depth

### Application Structure

**Routing Architecture**
- File-based routing with Expo Router following Next.js patterns
- Root layout (`app/_layout.js`) wraps entire app with GestureHandler and StatusBar
- Route groups for logical separation:
  - `(onboarding)`: Intro, Login, Signup, Forgot Password
  - `(tabs)`: Main app sections (Home, Orders, Favorites, Profile)
  - Standalone routes: Store details, Cart, Checkout, Booking

**Screen Categories**

*Authentication & Onboarding*
- Animated intro slides showcasing app features
- User registration with validation
- Social login support
- Password recovery flow

*Core Features*
- **Home**: Location-based store discovery, category browsing, featured stores with ratings and distance
- **Store Details**: Tabbed interface (Products, Services, Reviews, Info) with hero images
- **Shopping Cart**: Item management with quantity controls and price calculation
- **Booking**: Interactive calendar and time slot selection for service appointments
- **Checkout**: Multi-step flow with address selection, payment method, and order summary
- **Notifications**: Real-time notification center with read/unread status
- **Personal Data**: User profile management with pet information
- **Addresses**: Multiple address management with default selection
- **Payment Methods**: Secure credit card management
- **Help Center**: Multi-channel customer support (chat, phone, email, WhatsApp)
- **FAQ**: Organized frequently asked questions by category
- **Notification Settings**: Granular notification preferences
- **Privacy & Security**: Account security with biometric and 2FA options
- **Terms of Use**: Legal documentation and user agreements
- **Orders**: Historical order tracking with status badges
- **Favorites**: Quick access to saved stores
- **Profile**: User settings, addresses, payment methods, support access

**State Management**
- Local component state using React hooks (useState)
- No global state management library currently implemented
- Designed for future integration with context API or state management solution

**Data Layer**
- Mock data constants (`constants/mockData.js`) for development
- Structured data models for stores, products, services, categories, and orders
- Architecture prepared for backend API integration

### External Dependencies

**Core Framework Dependencies**
- **Expo SDK (~54.0.23)**: Managed workflow for React Native development
- **React (19.1.0)**: UI library
- **React Native (0.81.5)**: Mobile framework
- **React DOM (^19.1.0)**: Web compatibility layer

**Navigation & Routing**
- **expo-router (^6.0.14)**: File-based routing
- **expo-linking (^8.0.8)**: Deep linking support
- **react-native-safe-area-context (^5.6.2)**: Safe area handling for notched devices

**Animation & Gestures**
- **react-native-reanimated (^4.1.3)**: Performant animations
- **react-native-gesture-handler (^2.29.1)**: Native gesture recognition
- **react-native-worklets (^0.6.1)**: UI thread JavaScript execution

**UI Components & Styling**
- **@expo/vector-icons (^15.0.3)**: Icon library (Ionicons)
- **expo-linear-gradient (^15.0.7)**: Gradient rendering
- **expo-font (^14.0.9)**: Custom font loading
- **expo-status-bar (~3.0.8)**: Status bar configuration

**Platform Support**
- **react-native-web (^0.19.13)**: Web platform compatibility (configured for port 5000)

**Build Tools**
- **@babel/core (^7.25.2)**: JavaScript compiler
- **babel-preset-expo (^54.0.7)**: Expo-specific Babel configuration
- **react-native-reanimated/plugin**: Babel plugin for Reanimated worklets

**Configuration**
- Metro bundler with default Expo configuration
- Expo new architecture enabled for improved performance
- Deep linking scheme: `petsgo://`
- Edge-to-edge display for Android
- Adaptive icons and splash screens configured

**Future Integration Points**
- Backend API for stores, products, services, and orders
- Authentication service (OAuth, JWT)
- Payment gateway integration
- Push notifications (via Expo Notifications)
- Geolocation services for store discovery
- Image upload and CDN integration
- Real-time order tracking
- Database for persistent storage (Drizzle ORM ready for Postgres or other adapters)